const { chromium } = require('playwright');
const fs = require('node:fs');
(async () => {
  const browser = await chromium.launch({executablePath: '/usr/bin/chromium', headless: true, args: ['--no-sandbox']});
  try {
    const context = await browser.newContext({httpCredentials: {username: 'h3', password: 'test-only-password'}});
    const page = await context.newPage();
    const errors = [];
    page.on('pageerror', error => errors.push(String(error)));
    await page.goto(process.argv[2]);
    await page.locator('#qualityControls input').first().waitFor();
    await page.locator('#promptMode').selectOption('manual_final');
    await page.locator('#manualFinalPrompt').fill('Reference 1 walks across the sunlit room. Preserve identity and clothing.');
    await page.locator('#duration').fill('5');
    await page.locator('#seed').fill('12345');
    const png = fs.readFileSync(process.argv[3]);
    const file = i => ({name: `reference-${i}.png`, mimeType: 'image/png', buffer: png});
    for (const profile of ['h3_full', '10eros_full']) {
      await page.locator('#model').selectOption(profile);
      await page.locator('#pic').setInputFiles(file(0));
      await page.locator('#refs').setInputFiles([1,2,3,4,5].map(file));
      const response = page.waitForResponse(r => r.url().endsWith('/api/batches') && r.request().method() === 'POST');
      await page.locator('#generateBatch').click();
      const result = await response;
      if (result.status() !== 200) throw Error(await result.text());
      const body = result.request().postDataJSON();
      if (body.seed !== 12345 || body.profile !== profile || body.prompt_mode !== 'manual_final') throw Error('browser request lost settings');
      console.log(JSON.stringify({profile, seed: body.seed, uploads: body.pictures.length, duration: body.duration_seconds, http: result.status()}));
    }
    await page.waitForFunction(() => [...document.querySelectorAll('#jobs a')].filter(a => a.textContent.includes('OPEN MP4')).length === 2);
    const links = await page.locator('#jobs a').evaluateAll(nodes => nodes.filter(n => n.textContent.includes('OPEN MP4')).map(n => n.href));
    for (const link of links) {
      const response = await context.request.get(link, {headers: {Range: 'bytes=0-15'}});
      if (response.status() !== 206 || (await response.body()).length !== 16) throw Error('Range failed');
    }
    const video = await page.evaluate(async link => {
      const video = document.createElement('video'); video.src = link; document.body.append(video);
      await new Promise((resolve, reject) => {video.onloadedmetadata = resolve; video.onerror = () => reject(Error('video decode failed'));});
      return {width: video.videoWidth, height: video.videoHeight, duration: video.duration};
    }, links[0]);
    if (!video.width || !video.height || !video.duration || errors.length) throw Error(JSON.stringify({video, errors}));
    console.log(JSON.stringify({openMp4: links.length, range: 'PASS', syntheticVideoMetadata: video, pageErrors: errors}));
  } finally { await browser.close(); }
})().catch(error => {console.error(error); process.exitCode = 1;});
