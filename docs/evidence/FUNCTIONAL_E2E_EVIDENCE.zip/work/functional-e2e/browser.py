import asyncio
from contextlib import ExitStack
import os
from pathlib import Path
import socket
import subprocess
import threading
import time
from unittest.mock import patch

import uvicorn

from tests.helpers import load_controller
from tests.functional_e2e_support import Backend, PNG, stage_models

root = Path('work/functional-e2e').absolute()
(root / 'reference.png').write_bytes(PNG)
subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-f', 'lavfi', '-i', 'color=c=blue:s=64x64:r=24:d=1',
    '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-movflags', '+faststart', '-y', str(root / 'fixture.mp4')], check=True)
with ExitStack() as stack:
    m = stack.enter_context(load_controller(production_probes=True))
    stage_models(m)
    backends = {s: Backend(m, s) for s in ('render', 'prompt')}
    for backend in backends.values():
        stack.callback(backend.close)
    backends['render'].media = (root / 'fixture.mp4').read_bytes()
    m.RENDER_COMFY_URL, m.PROMPT_COMFY_URL = backends['render'].url, backends['prompt'].url
    m.COMFY_PYTHON = os.environ['AJ_E2E_COMFY_PYTHON']
    # Only an owned render scheduler runs. No provider or prompt scheduler.
    async def app_start():
        m.render_worker_task = asyncio.create_task(m.render_worker())
    async def app_stop():
        m.render_worker_task.cancel()
        await asyncio.gather(m.render_worker_task, return_exceptions=True)
    m.app.router.on_startup[:] = [app_start]
    m.app.router.on_shutdown[:] = [app_stop]
    listener = socket.socket(); listener.bind(('127.0.0.1', 0)); listener.listen()
    stack.callback(listener.close)
    server = uvicorn.Server(uvicorn.Config(m.app, log_level='error'))
    thread = threading.Thread(target=server.run, kwargs={'sockets': [listener]}, daemon=True)
    thread.start()
    try:
        deadline = time.monotonic() + 10
        while not server.started:
            if time.monotonic() > deadline: raise RuntimeError('panel startup timed out')
            time.sleep(.05)
        subprocess.run(['node', str(root / 'browser.js'), f'http://127.0.0.1:{listener.getsockname()[1]}',
            str(root / 'reference.png')], check=True, timeout=50)
        print('Controller render statuses:', [(j['profile'], j['status'], j['render_seed']) for j in m.queue])
        assert len(backends['render'].submissions) == 2
        assert backends['prompt'].calls == []
    finally:
        server.should_exit = True
        thread.join(timeout=10)
        assert not thread.is_alive()
