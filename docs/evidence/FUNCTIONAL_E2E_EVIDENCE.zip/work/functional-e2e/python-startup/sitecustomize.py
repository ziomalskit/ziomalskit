import os
if os.environ.get("AJ_E2E_COMFY_PYTHON"):
    import comfy_cli.constants as c
    c.DEFAULT_CONFIG = {k: os.environ["AJ_E2E_CLI_CONFIG"] for k in c.DEFAULT_CONFIG}
