Functional readiness evidence for issue #11 / Draft PR #12

Base: d5b71fa4ca3dd085abf570ad369cac4007226d1d
Tested production source commit: 526368ac8be8e8b3281cccf1ae38914a41d904db

Read docs/FUNCTIONAL_E2E_READINESS.md first. Synthetic inference and synthetic
media do not prove GPU/model acceptance. No credentials or SSH private keys
are included. Apply functional-e2e-fix.patch to the base, or check out PR #12.
Later evidence-only commits do not change tested production files.

Reproduce normal regression from repository root:
  make setup
  .venv/bin/python -m unittest tests.test_functional_e2e tests.test_manual_prompt_frontend tests.test_frontend_retry -v

Optional actual CLI reproduction (no production model download): extract the
work/functional-e2e directory into your repository's work/ directory, then:
  .venv/bin/python -m venv work/functional-e2e/venv
  work/functional-e2e/venv/bin/pip install -r requirements/panel.lock comfy-cli==1.21.0
  export AJ_E2E_COMFY_PYTHON="$PWD/work/functional-e2e/venv/bin/python"
  export AJ_E2E_CLI_CONFIG="$PWD/work/functional-e2e/cli-config"
  export AJ_E2E_TRACE_DIR="$PWD/work/functional-e2e/traces"
  export PYTHONPATH="$PWD/work/functional-e2e/python-startup:$PWD"
  work/functional-e2e/venv/bin/python -m unittest tests.test_functional_e2e -v

CLI config is redirected into work/ and telemetry is disabled. The original
review used the isolated interpreter versions recorded in provenance.json;
this reproduction installs the repository's current development lock.

Optional browser reproduction needs Node.js, Playwright, /usr/bin/chromium,
ffmpeg and libx264. With the CLI environment above:
  work/functional-e2e/venv/bin/python work/functional-e2e/browser.py

Staged Docker transaction (simulated hardware/native checks/service commands):
  PYTHONPATH="$PWD" .venv/bin/python work/functional-e2e/deployment.py

The entrypoint namespace script is evidence of a rootless limitation, not a
Vast deployment procedure. Its arguments must name disposable directories.
Do not run it against real home/SSH paths. The original run generated keys and
started SSH, then failed login at setgroups; no working host SSH claim is made.

Logs named boundaries.log contain some fixture-native success messages.
These are simulated native/hardware tests, not actual Sage/GPU execution.
The published-image logs are prior CI evidence dated 5 November 2026.
No local complete image pull or new image publication was performed.

The full make test run passed, followed by final focused frontend/browser and
expanded failure-boundary checks. No local make audit repetition was needed
for this functional review. Existing GitHub CPU CI is independent evidence.
