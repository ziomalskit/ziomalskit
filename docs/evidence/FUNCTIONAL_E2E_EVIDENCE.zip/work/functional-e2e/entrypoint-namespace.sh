#!/usr/bin/env bash
set -euo pipefail
case_root="$1"
entrypoint="$2"
mount --make-rprivate /
mount --bind "$case_root/root" /root
mount --bind "$case_root/run" /run
mount --bind "$case_root/ssh" /etc/ssh
ip link set lo up
export PUBLIC_KEY
PUBLIC_KEY="$(cat "$case_root/id.pub")"
bash "$entrypoint" >"$case_root/entrypoint.log" 2>&1 &
entry_pid=$!
trap 'kill "$entry_pid" 2>/dev/null || true; wait "$entry_pid" 2>/dev/null || true' EXIT
for attempt in {1..20}; do
  if [[ -f /run/aj-boot-id ]]; then break; fi
  sleep .1
done
ssh -F /dev/null -i "$case_root/id" -o BatchMode=yes -o ConnectTimeout=3 \
  -o StrictHostKeyChecking=no -o "UserKnownHostsFile=$case_root/known_hosts" \
  root@127.0.0.1 'printf "AJ SSH COMMAND PASS\n"'
