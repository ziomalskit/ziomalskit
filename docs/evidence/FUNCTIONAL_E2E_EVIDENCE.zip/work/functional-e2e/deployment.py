"""Review-only staged Docker transaction. Hardware/services/weights simulated."""
from contextlib import ExitStack
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
from unittest.mock import patch

from h3.docker import instance as d
from h3.scripts import provision_models, model_downloads

work = Path('work/functional-e2e').absolute()
with tempfile.TemporaryDirectory(dir=work, prefix='deployment-') as temporary, ExitStack() as stack:
    base = Path(temporary)
    root = base / 'workspace'
    seed = base / 'seed'; seed.mkdir(); (seed / 'main.py').write_text('# inert Comfy fixture')
    for key, value in [('ROOT', root), ('SEED', seed), ('IMAGE', base / 'image.json'), ('BOOT', base / 'boot')]:
        stack.enter_context(patch.object(d, key, value))
    d.IMAGE.write_text(json.dumps({'revision': 'd5b71fa4ca3dd085abf570ad369cac4007226d1d'}))
    d.BOOT.write_text('synthetic-boot-1')
    calls = []
    stack.enter_context(patch.object(d.getpass, 'getpass', return_value='CPU-fixture-password-only'))
    original_run = d.run
    def command(args, **kwargs):
        calls.append(list(map(str, args)))
        if str(args[1]).endswith('/process_identity.py'):
            return original_run(args, **kwargs)
        if any(str(v).endswith('/provision_models.py') for v in args):
            def local_download(root, item):
                def receive(_item, stage):
                    path = stage / 'payload'; path.write_bytes(payloads[item['id']]); return path
                return model_downloads.ensure_download(root, item, downloader=receive)
            with patch.object(provision_models, 'ensure_download', side_effect=local_download):
                result = provision_models.provision(manifest, root / 'ComfyUI/models', base / 'unused-toolchain')
            assert len(result) == 2
    stack.enter_context(patch.object(d, 'run', side_effect=command))
    try:
        d.execute('init')
    except (ValueError, OSError, subprocess.SubprocessError) as error:
        print('ACTUAL RUNNER init BLOCKED:', str(error))
    else:
        raise AssertionError('GPU-free undersized runner was accepted')
    assert calls == []
    assert not (root / 'H3_VAST_MOBILE/runtime.env').exists()
    print('PASS: actual pre-model failure made zero native/downloader/service calls')
    manifest = json.loads((d.PACKAGE / 'config/models_manifest.json').read_text())
    manifest['artifacts'] = manifest['artifacts'][:2]
    payloads = {}
    for item in manifest['artifacts']:
        data = b'INERT REVIEW FIXTURE ' + item['id'].encode(); payloads[item['id']] = data
        item.update(size_bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    stack.enter_context(patch.object(d, 'selected_models', return_value=(manifest, set(), {i['id']: i for i in manifest['artifacts']})))
    stack.enter_context(patch.object(d, 'cgroup_limits', return_value=(128 * 1024**3, 16, [])))
    original_plan = d.disk_plan
    def disk(*args, **kwargs):
        return {**original_plan(*args, **kwargs), 'free_bytes': 400 * 1024**3}
    stack.enter_context(patch.object(d, 'disk_plan', side_effect=disk))
    def output(args):
        if args[0] == 'findmnt': return json.dumps({'filesystems': [{'target': str(root), 'options': 'rw'}]})
        return 'GPU-FIXTURE, NVIDIA RTX PRO 6000 Blackwell, 580.65.06, 97887, 12.0'
    stack.enter_context(patch.object(d, 'output', side_effect=output))
    stack.enter_context(patch.object(d.sage, 'install'))
    d.execute('init')
    assert not d.ready_path().exists()
    try: d.execute('start')
    except FileNotFoundError: pass
    else: raise AssertionError('start bypassed missing model receipt')
    print('PASS: simulated healthy init is model-free; start refuses missing receipt')
    before = len(calls)
    d.execute('models')
    assert sum(any(v.endswith('/provision_models.py') for v in row) for row in calls) == 1
    d.execute('start')
    assert [row[-2:] for row in calls[-4:-2]] == [['start', 'all'], ['restart', 'panel']]
    print('PASS: explicit models uses real tiny-file downloader/provisioner and publishes ready receipt; start dispatches service/preflight/smoke boundaries (SIMULATED)')
    from h3.scripts.runtime_config import read_env
    assert read_env(root / 'H3_VAST_MOBILE/runtime.env')['H3_ALLOW_SUBMISSIONS'] == '0'
    d.BOOT.write_text('synthetic-boot-2')
    try: d.service_check()
    except ValueError: pass
    else: raise AssertionError('stale boot accepted')
    d.BOOT.write_text('synthetic-boot-1')
    path = root / 'ComfyUI/models' / manifest['artifacts'][0]['destination']
    path.write_bytes(b'changed fixture')
    try: d.service_check()
    except ValueError: pass
    else: raise AssertionError('changed model accepted')
    print('PASS: stale boot and changed model signatures refuse restart; submissions OFF')
